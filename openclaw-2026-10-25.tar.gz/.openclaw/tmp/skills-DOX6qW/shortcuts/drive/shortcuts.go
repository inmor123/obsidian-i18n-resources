// Copyright (c) 2026 Lark Technologies Pte. Ltd.
// SPDX-License-Identifier: MIT

package drive

import "github.com/larksuite/cli/shortcuts/common"

// Shortcuts returns all drive shortcuts.
func Shortcuts() []common.Shortcut {
	return []common.Shortcut{
		DriveUpload,
		DriveCreateFolder,
		DriveCreateShortcut,
		DriveDownload,
		DrivePreview,
		DriveCover,
		DriveAddComment,
		DriveExport,
		DriveExportDownload,
		DriveImport,
		DriveVersionHistory,
		DriveVersionGet,
		DriveVersionRevert,
		DriveVersionDelete,
		DriveMove,
		DriveDelete,
		DriveStatus,
		DrivePush,
		DrivePull,
		DriveSync,
		DriveTaskResult,
		DriveApplyPermission,
		DriveSecureLabelList,
		DriveSecureLabelUpdate,
		DriveSearch,
		DriveInspect,
	}
}
